# LO-2.1: Suite File Structure

## Overview
This demonstration teaches how Robot Framework organizes test files and directories into a hierarchical suite structure. Students will learn how RF automatically creates a test suite tree from file and directory organization, including naming conventions and execution order.