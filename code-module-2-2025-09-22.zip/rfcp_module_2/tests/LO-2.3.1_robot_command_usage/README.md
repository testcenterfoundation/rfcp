Run all tests from test suite directory

`cd tests/k2_demos/LO-2.3.1_robot_command_usage/`

`robot .`

Output to a specific output directory:

`robot -d results .`

==============================================================================
LO-2.3.1 robot command usage                                                  
==============================================================================
LO-2.3.1 robot command usage.Demo                                             
==============================================================================
Login User With Password                                              | PASS |
------------------------------------------------------------------------------
Denied Login With Wrong Password                                      | PASS |
------------------------------------------------------------------------------
LO-2.3.1 robot command usage.Demo                                     | PASS |
2 tests, 2 passed, 0 failed
==============================================================================
LO-2.3.1 robot command usage                                          | PASS |
2 tests, 2 passed, 0 failed
==============================================================================
Output:  /Users/roy/tmp/robotframework-courseware/tests/k2_demos/LO-2.3.1_robot_command_usage/output.xml
Log:     /Users/roy/tmp/robotframework-courseware/tests/k2_demos/LO-2.3.1_robot_command_usage/log.html
Report:  /Users/roy/tmp/robotframework-courseware/tests/k2_demos/LO-2.3.1_robot_command_usage/report.html