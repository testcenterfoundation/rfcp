`cd tests/k2_demos/LO-2.3.4_log_vs_console_output/`

robot --loglevel DEBUG demo.robot