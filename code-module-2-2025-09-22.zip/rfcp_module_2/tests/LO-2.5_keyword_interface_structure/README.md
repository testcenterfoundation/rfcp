Generate documentation

`cd tests/k2_demos/LO-2.5_keyword_interface_structure/`

`libdoc resources/custom.resource output/custom_keywords.html`