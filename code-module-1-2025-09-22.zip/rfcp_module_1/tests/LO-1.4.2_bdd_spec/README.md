# Learning Objective: LO-1.4.2 Behavior-Driven Specification (BDD)

## Overview
This demo introduces Behavior-Driven Development (BDD) style testing using the Given-When-Then format. BDD bridges the gap between business stakeholders and technical teams by using a common language to describe system behavior.