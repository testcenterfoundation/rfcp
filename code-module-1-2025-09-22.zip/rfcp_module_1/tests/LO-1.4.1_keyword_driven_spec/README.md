# Learning Objective: LO-1.4.1 Keyword-Driven Specification

## Overview
This demo introduces the Keyword-Driven Testing approach, where tests are written using high-level, business-readable keywords that describe WHAT the system should do rather than HOW it does it.
