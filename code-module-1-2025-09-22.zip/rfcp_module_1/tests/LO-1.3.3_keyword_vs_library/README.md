# Learning Objective: LO-1.3.3 Keyword vs Library

## Overview
This demo illustrates the fundamental difference between Library Keywords (built-in or imported) and User Keywords (custom-defined). Students will understand how to use both types and when each is appropriate.
